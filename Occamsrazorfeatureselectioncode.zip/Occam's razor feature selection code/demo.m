clc; clear; close all; warning('off');
% This demo runs the prostate cancer dataset. This dataset has 21 samples
% and 12600 features. This program should take almost 10 seconds to run.
tic;
addpath('./fspackage','./dataset','./Occams_razor_fs');  
load('prostat_Cancer.mat'); X=prostat_cancer(:,1:end-1);  Y=prostat_cancer(:,end); % loading the dataset
[features]=occam_razor_fs(X,Y);     % applying the Occam's razor feature selecion algorithm
toc;
