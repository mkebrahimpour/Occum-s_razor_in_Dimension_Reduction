function [features]=occam_razor_fs(X,Y)
%function []=occam_razor_fs(X,Y)
% This function selects features according to the following paper:
% Ebrahimpour Et al. Occam's razor in dimension reduction: using reduced
% row Echelon form for finding linear independent features in high
% dimensional microarray datasets, Eng Appl. Artif. Intel.(2017)
% In:
%     X: n x d training set (n: number of samples, d:number of features)
%     Y: n x 1 training labels
% Out:
%     features: 1 x ? vector, contains the best subset of features.

% Copyright (c) 2016 by Mohammad Kazem Ebrahimpour, Masoumeh Zare,Mahdi
% Eftekhari and Gholamreza Aghamolaei

try
    load_fspackage;
    %% Sort (Maximum Relevancy)
    fprintf('Sorting features by their importance (Maximum Relevancy)...\n');
    Gain_obj=fsInfoGain(X,Y); weights=Gain_obj.W; [~,index]=sort(weights,'descend');
    X=X(:,index);  % sorting the features based on their importance
    
    %% Solving AX=0 (Minimum Redundancy)
    fprintf('Solving AX=0 (Minimum Redundancy)...\n');
    [~,col]=rref(X);features=index(col);  % removing redundant features
    
    fprintf('Feature selection has been done!\n');
catch
    fprintf(':( Something went wrong,Please run the program again.\n');
    features=[];
end




end